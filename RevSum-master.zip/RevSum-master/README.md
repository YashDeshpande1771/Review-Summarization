# RevSum
BE Project

# Imp Links

### Ultimate guide to deal with Text Data – ALL BASIC INFO
- https://www.analyticsvidhya.com/blog/2018/02/the-different-methods-deal-text-data-predictive-python/

### Example Extention which used NLP 
- https://github.com/CCEM/nlp-chrome-extension

### NeuralCoref: Coreference Resolution in spaCy with Neural Networks (retraining possible)
- https://github.com/huggingface/neuralcoref
- https://huggingface.co/coref/
- https://medium.com/huggingface/state-of-the-art-neural-coreference-resolution-for-chatbots-3302365dcf30

### Review Browser 
- http://www.opener-project.eu/project/demos/





#### for Product Related Vocabulary
#### ConceptNet.io - http://www.conceptnet.io 
OR
#### Datamuse API - https://www.datamuse.com/api/


##### For TFIDF - http://kavita-ganesan.com/extracting-keywords-from-text-tfidf/#.XD4xQ8ZOk8o


#### Word to vec
##### Stanford- https://nlp.stanford.edu/projects/glove/


#### for similarity between word vectors https://github.com/JRC1995/Abstractive-Summarization

#### query based extractive summarization www.aclweb.org/anthology/W17-1004

#### https://pytorch.org/tutorials/beginner/nlp/word_embeddings_tutorial.html#sphx-glr-beginner-nlp-word-embeddings-tutorial-py

#### sentence compression: https://github.com/code4conference/code4sc
