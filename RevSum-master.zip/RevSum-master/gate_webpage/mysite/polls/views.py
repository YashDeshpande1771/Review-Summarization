'''
from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse


def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")
'''
from django.shortcuts import render
from django.http import HttpResponse
from lxml import html  
import requests
import pandas as pd
import time

def index(request):
	return render(request,'polls/index.html')

def getData(request):
	if request.method == "POST":
		screenname = request.POST.get("userid", None)
		screenname=str(screenname)
		screenname = screenname[39:49]

		product_id = screenname  ## Fetched from user inputted url {Assigned to: Hrushikesh Gate }
		j=1
		amazon_url = 'https://www.amazon.com/product-reviews/'+ product_id + '?pageNumber=1' 
		user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'
		headers = {'User-Agent': user_agent}
		page = requests.get(amazon_url, headers = headers)
		parser = html.fromstring(page.content)

#xpath_pagination_bar = '//div[@data-hook="pagination-bar"]'
#pagination_bar = parser.xpath(xpath_pagination_bar)

		page_list = []
		for el in parser.xpath('//div[@data-hook="pagination-bar"]/ul/li[@data-reftag="cm_cr_arp_d_paging_btm"]//text()'):
			page_list.append(int(el))
		    
		page_count = 5
		if page_count>10:
			page_count = 10

		for j in range(1,page_count):
			try:
				time.sleep(2)
				amazon_url = 'https://www.amazon.com/product-reviews/'+ product_id + '?pageNumber=' + str(j)
				#return HttpResponse(amazon_url)
				user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'
				if(j==1):
					reviews_df = pd.DataFrame()

				headers = {'User-Agent': user_agent}
				page = requests.get(amazon_url, headers = headers)
				parser = html.fromstring(page.content)

				xpath_reviews = '//div[@data-hook="review"]'
				reviews = parser.xpath(xpath_reviews)

				xpath_rating  = './/i[@data-hook="review-star-rating"]//text()' 
				xpath_title   = './/a[@data-hook="review-title"]//text()'
				xpath_author  = './/a[@data-hook="review-author"]//text()'
				xpath_date    = './/span[@data-hook="review-date"]//text()'
				xpath_body    = './/span[@data-hook="review-body"]//text()'
				xpath_helpful = './/span[@data-hook="helpful-vote-statement"]//text()'

				for review in reviews:
					rating  = review.xpath(xpath_rating)
					title   = review.xpath(xpath_title)
					author  = review.xpath(xpath_author)
					date    = review.xpath(xpath_date)
					body    = review.xpath(xpath_body)
					helpful = review.xpath(xpath_helpful)

					review_dict = {'rating': rating,
					'title': title,
					'author': author,             
					'date': date,
					'body': body,
					'helpful': helpful}
					reviews_df = reviews_df.append(review_dict, ignore_index=True)
			except requests.exceptions.ConnectionError:
				print("Connection refused")
	return HttpResponse(reviews_df.head())
	
