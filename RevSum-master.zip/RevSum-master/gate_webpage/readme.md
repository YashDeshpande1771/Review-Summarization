1. install django
sudo apt-get install python3-django

2. create project

django-admin startproject mysite

3. start server

python manage.py runserver

4. create our own app

To create your app, make sure you’re in the same directory as manage.py and type this command:

python3 manage.py startapp polls

5. after this, iss mai se dekh lo-

https://docs.djangoproject.com/en/2.1/intro/tutorial01/



